import java.util.Scanner;

public class Company {
    private final String COMPANY = "AegDevelopment";
    private String department;

    //constructor
    public Company() {
    }

    //getters and setters for fields
    public String getCOMPANY() {
        return COMPANY;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    //asks for typing department
    public String askForDepartment(User usr) {
        System.out.println(usr.getEmailUser() + ", wybierz numer działu, w którym pracujesz:");
        System.out.println("1 - Backend, 2 - Frontend, 3 - Testing, 4 - HR");
        Scanner input = new Scanner(System.in);
        int chosenDepartmentNumber = input.nextInt();

        if (chosenDepartmentNumber == 1) {
            this.department = "Backend";
        }
        else if (chosenDepartmentNumber == 2) {
            this.department = "Frontend";
        }
        else  if (chosenDepartmentNumber == 3) {
            this.department = "Testing";
        }
        else if (chosenDepartmentNumber == 4) {
            this.department = "HR";
        }
        else System.out.println("Nie wybrano poprawnej wartości");
        return department;
    }
}
