import java.util.Scanner;


public class Email {


    private String email;
    private String password;
    private String emailUser;
    private int defaultPasswordLength = 8;
    private String defaultPassword;



//constructor without parameters; we will create an email in method createEmail()
    public Email() {
    }

//getters and setters for fields
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getDefaultPasswordLength() {
        return defaultPasswordLength;
    }

    public void setDefaultPasswordLength(int defaultPasswordLength) {
        this.defaultPasswordLength = defaultPasswordLength;
    }

    public String getDefaultPassword() {
        return defaultPassword;
    }

    public void setDefaultPassword(String defaultPassword) {
        this.defaultPassword = defaultPassword;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmailUser() {
        return emailUser;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }


//method creates email using data typed by the user (methods createUser() & askForDepartment())
    public String createEmail(User usr, Company cmp) {
        System.out.println(usr.getEmailUser() + ", wybrany przez Ciebie dział to " + cmp.getDepartment() + ". Wprowadzone dane " +
                "zostaną użyte do wygenerowania adresu email. \nAby potwierdzić i utworzyć email, wpisz t i wciśnij Enter. " +
                "Aby przerwać, wpisz n i naciśnij Enter. ");
        String message;
        Scanner input = new Scanner(System.in);
        String createEmailConfirmation = input.nextLine();
        if (createEmailConfirmation.equals("t")) {
            String emailWithPolishSigns = usr.getFirstname().toLowerCase() + "." + usr.getLastname().toLowerCase() + "@"
                    + cmp.getDepartment().toLowerCase() + "." + cmp.getCOMPANY().toLowerCase() + ".com";
            //changes polish letters for letters from latin alphabet
            String emailWithoutPolishSigns = emailWithPolishSigns.replace('ą', 'a').replace('ę', 'e')
                    .replace('ł', 'l').replace('ó', 'o').replace('ś', 's')
                    .replace('ż', 'z').replace('ź', 'z');
            this.email = emailWithoutPolishSigns;
            message = usr.getEmailUser() + ", Twój firmowy email to " + getEmail();
            System.out.println(message);
            //generates default password for email
            generateDefaultPassword(getDefaultPasswordLength());
        }

        else if (createEmailConfirmation.equals("n")) {
            message = usr.getEmailUser() + ", zdecydowałeś się przerwać proces tworzenia emaila. Aby ponowić próbę, " +
                    "uruchom program ponownie.";
            System.out.println(message);
        }

        else {
            message = "Nieprawidłowy wybór. Nastąpi zakończenie programu.";
            System.out.println(message);
        }
     return message;
    }

    //generates default email password
    public String generateDefaultPassword(int defaultPasswordLength) {

        System.out.println("System wygenerował domyślne hasło dla Twojego nowego adresu." );
        String passwordSet = "AaBbCcDdEeFfGgHhIiJjKkLlMmNnOoPpQqRrSsTtUuWwXxYyZz!?,#%&*";
        char [] defaultPassword = new char [getDefaultPasswordLength()];
        for (int i = 0; i<defaultPasswordLength; i++) {
            int rand = (int) (Math.random() * passwordSet.length());
            defaultPassword[i] = passwordSet.charAt(rand);
        }
        System.out.println("Twoje nowe hasło to " + defaultPassword +". Zalecana jest jego zmiana w późniejszym terminie.");
        return new String (defaultPassword);
    }


}
