/*Simple console program which gets data from user (name, username, department
* and generates company email address with random password
* Author: Rafał Kępa, rafalmkepa@gmail.com*/


public class EmailApp {
    public static void main (String[] args){

    //Creates new instances of User, Email & Company classes
        Email eml = new Email();
        Company cmp = new Company();
        User usr = new User();

    //gets company object, asks for firstname & lastnamae & finally creates new user
        usr.createUser(cmp);

    //gets created user and asks for a department
        cmp.askForDepartment(usr);

     //gets user & company objects & creates user's email; if email was created, method also generate default password
        eml.createEmail(usr, cmp);

    }

}
