import java.util.Scanner;

public class User {
    private String firstname;
    private String lastname;
    private String emailUser;

    //constructor
    public User() {
    }


    //getters and setters for fields
    public String getFirstname() {
        return firstname;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getEmailUser() {
        return emailUser;
    }

    public void setEmailUser(String emailUser) {
        this.emailUser = emailUser;
    }

    //method creates user
    public String createUser(Company cmp) {
        System.out.println("Firma " + cmp.getCOMPANY() + " wita w systemie generującym firmowe konta email. Wpisz imię i naciśnij Enter");
        Scanner input = new Scanner(System.in);
        this.firstname = input.nextLine();
        System.out.println("Wpisz nazwisko i naciśnij Enter");
        this.lastname = input.nextLine();
        emailUser = firstname + " " + lastname;
        return emailUser;
    }
}
